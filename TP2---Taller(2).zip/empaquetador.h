#ifndef EMPAQUETADOR_H
#define EMPAQUETADOR_H

int empaquetador(int largo_array_nombres, char* array_nombre_archivos[]);

#endif // EMPAQUETADOR_H
